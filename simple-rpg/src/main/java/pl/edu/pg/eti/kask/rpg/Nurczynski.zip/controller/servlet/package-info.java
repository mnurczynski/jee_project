/**
 * Servlets for handling characters HTTP request. Servlets are fundamental elements of web applications. This the most
 * (not counting writing own socket support) basic way of handling requests.
 */
package pl.edu.pg.eti.kask.rpg.controller.servlet;
