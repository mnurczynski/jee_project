/**
 * Controllers interfaces. Can be used to provide different implementations of controller functionality.
 */
package pl.edu.pg.eti.kask.rpg.controller;
