/**
 * Package for Servlet web listener implementing hooks for application lifecycle events.
 */
package pl.edu.pg.eti.kask.rpg.configuration.observer;
