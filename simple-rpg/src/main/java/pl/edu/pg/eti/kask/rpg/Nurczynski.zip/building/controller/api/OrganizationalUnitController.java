package pl.edu.pg.eti.kask.rpg.building.controller.api;

import pl.edu.pg.eti.kask.rpg.building.dto.GetOrganizationalUnitsResponse;

public interface OrganizationalUnitController {

    GetOrganizationalUnitsResponse getOrganizationalUnits();
}
