package pl.edu.pg.eti.kask.rpg.user.entity;

public enum Type {
    MANAGER,
    BUILDING_ADMINISTRATOR,
    READ_ONLY_USER
}
