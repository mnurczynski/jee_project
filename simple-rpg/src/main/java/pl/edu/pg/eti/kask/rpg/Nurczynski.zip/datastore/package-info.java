/**
 * Instead of using real connection to database mocks from this package can be used.
 */
package pl.edu.pg.eti.kask.rpg.datastore;
