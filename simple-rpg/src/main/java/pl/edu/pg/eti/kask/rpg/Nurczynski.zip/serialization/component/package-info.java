/**
 * Package form components implementing some functionalities but not representing business logic.
 */
package pl.edu.pg.eti.kask.rpg.serialization.component;
