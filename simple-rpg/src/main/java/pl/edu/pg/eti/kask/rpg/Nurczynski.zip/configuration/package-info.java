/**
 * Package for configuration considering application as a whole (not particular mechanism).
 */
package pl.edu.pg.eti.kask.rpg.configuration;
