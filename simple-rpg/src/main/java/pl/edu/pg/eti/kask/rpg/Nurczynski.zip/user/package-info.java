/**
 * Util classes for serialization.
 */
package pl.edu.pg.eti.kask.rpg.user;
