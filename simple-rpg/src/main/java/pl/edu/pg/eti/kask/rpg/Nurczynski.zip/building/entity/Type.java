package pl.edu.pg.eti.kask.rpg.building.entity;

public enum Type {
    FACULTY,
    ADMINISTRATIVE_DEPARTMENT,
    INSTITUTE,
    CENTER
}
