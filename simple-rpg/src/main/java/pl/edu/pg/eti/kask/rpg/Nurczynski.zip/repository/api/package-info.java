/**
 * Repositories interfaces. Can be used to provide different implementations of repositories functionality.
 */
package pl.edu.pg.eti.kask.rpg.repository.api;
