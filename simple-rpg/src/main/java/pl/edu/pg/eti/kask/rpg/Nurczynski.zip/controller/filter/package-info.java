/**
 * Servlet filters are kind of interceptors considering http request. There can be an execution chain made of a number
 * of filters which typically ends with a servlet or some resource.
 */
package pl.edu.pg.eti.kask.rpg.controller.filter;
