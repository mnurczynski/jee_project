/**
 * Definition of exceptions which can be thrown in application.
 */
package pl.edu.pg.eti.kask.rpg.controller.servlet.exception;
